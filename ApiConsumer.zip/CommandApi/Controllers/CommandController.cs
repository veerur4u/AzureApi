﻿using CommandApi.Models;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CommandApi.Controllers
{
    public class CommandController : ApiController
    {
        // GET api/values
        [SwaggerOperation("GetCommands")]
        public IEnumerable<Commands> Get()
        {
            return new Commands[] { new Commands { Id = 1, Name = "SetPoint", Value = "10" }, new Commands { Id = 1, Name = "Humidity", Value = "20" } };
        }
    }
}
