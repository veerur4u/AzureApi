﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureStorageQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            //Retrieve Storage account from connection string
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);

            //Get a reference to the Queue client
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            //Get a reference to a Queue object
            CloudQueue queue = queueClient.GetQueueReference("storagequeue");
            queue.CreateIfNotExists();


            // queue.AddMessage(new CloudQueueMessage("Message #4"));
            //queue.AddMessage(new CloudQueueMessage("Message #2"));
            //queue.AddMessage(new CloudQueueMessage("Message #3"));




            //CloudQueueMessage peekedMessage = queue.PeekMessage();
            //Console.WriteLine(peekedMessage.AsString);
            //Console.Read();

            CloudQueueMessage message1 = queue.GetMessage();

             CloudQueueMessage message2 = queue.GetMessage();
            Console.WriteLine(message1.AsString);
             Console.WriteLine(message2.AsString);
           // queue.DeleteMessage(message1);
            Console.Read();



        }
    }
}
