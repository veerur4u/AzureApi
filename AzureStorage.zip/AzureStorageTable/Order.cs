﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureStorageTable
{
    public class Order :TableEntity
    {

        public Order(string customerName, String orderDate)
        {
            this.PartitionKey = customerName;
            this.RowKey = orderDate;
        }
        public Order() { }
        public string OrderNumber { get; set; }
        public string Status { get; set; }

    }
}
