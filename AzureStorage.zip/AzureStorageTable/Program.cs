﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureStorageTable
{
    class Program
    {
        static void Main(string[] args)
        {


            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);

            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();
            CloudTable table = tableClient.GetTableReference("orders");
            table.CreateIfNotExists();
            //Order newOrder = new Order("Archer", "20160118");
            //newOrder.OrderNumber = "101";
            //newOrder.Status = "shipped";
            //TableOperation insertOperation = TableOperation.Insert(newOrder);
            //table.Execute(insertOperation);



            TableBatchOperation batchOperation = new TableBatchOperation();

            Order newOrder1 = new Order("Lana", "20141217");
            newOrder1.OrderNumber = "102";
            newOrder1.Status = "pending";

            Order newOrder2 = new Order("Lana", "20141218");
            newOrder2.OrderNumber = "103";
            newOrder2.Status = "open";

            Order newOrder3 = new Order("Lana", "20141219");
            newOrder3.OrderNumber = "103";
            newOrder3.Status = "shipped";

            batchOperation.Insert(newOrder1);
            batchOperation.Insert(newOrder2);
            batchOperation.Insert(newOrder3);
            table.ExecuteBatch(batchOperation);



        }
    }
}
