﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureSBReceiver
{
    class Program
    {
        static string ConnectionString = "Endpoint=sb://vee-servicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=lsdw6uVBa9teI9BM6KDMN7wjZe9qI1yENcG4y9tzxik=";
        static string QueuePath = "sbqueue";
        static void Main(string[] args)
        {
            //Service Bus Queue Sender 
            var queueClient = QueueClient.CreateFromConnectionString(ConnectionString, QueuePath);
            queueClient.OnMessage(msg => ProcessMessage(msg));
            Console.WriteLine("Press Enter to Exit...");
            Console.ReadLine();
            queueClient.Close();
        }

        private static void ProcessMessage(BrokeredMessage msg)
        {
            var text = msg.GetBody<string>();
            Console.WriteLine("\nReceived Messages : " + text);
        }
    }
}
