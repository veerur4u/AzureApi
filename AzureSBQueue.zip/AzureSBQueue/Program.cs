﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureSBQueue
{
    class Program
    {
        static string ConnectionString = "Endpoint=sb://vee-servicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=lsdw6uVBa9teI9BM6KDMN7wjZe9qI1yENcG4y9tzxik=";
        static string QueuePath = "sbqueue";
        static void Main(string[] args)
        {
            //Service Bus Queue Sender 
            var queueClient = QueueClient.CreateFromConnectionString(ConnectionString, QueuePath); for (int i = 0; i < 10; i++)
            {
                var message = new BrokeredMessage("Sender's Message ==> " + i);

                queueClient.Send(message); Console.Write("\nSent Message : = " + i);
            }
            Console.WriteLine("Press Enter to Exit...");
            Console.ReadLine();
            queueClient.Close();
        }
    }
}
